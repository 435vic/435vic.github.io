float _a, _b;
int max;
color col;
final int colors = 20;

void setup () {
  size(1000, 1000);
  //fullScreen();
  max = 100;
  //colorMode(HSB);
}

void draw () {
  loadPixels();
  for (int x = 0; x < width; x++) {
    for (int y = 0; y < height; y++) {
      _a = map(x, 0, width, -2, 2);
      _b = map(y, 0, height, -2, 2);

      float a = _a;
      float b = _b;

      for (int i = 0; i < max; i++) {
        float aa = a * a - b * b;
        float bb = 2 * a * b;

        a = aa + _a;
        b = bb + _b;

        if (abs(a + b) > 2) {
          col = color(map(i, 0, max, 0, 255));
          break;
        } else {
          col = color(0, 0, 0);
        }
      }

      int index = x + y * max(width, height);
      pixels[index] = col;
    }
  }
  updatePixels();
  noLoop();
}